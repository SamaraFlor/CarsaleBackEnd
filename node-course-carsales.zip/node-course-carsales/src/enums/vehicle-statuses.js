exports.VehicleStatuses = {
  AVAILABLE: 'AVAILABLE',
  SOLD: 'SOLD',
};
