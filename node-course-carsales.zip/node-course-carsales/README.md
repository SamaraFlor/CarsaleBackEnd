# Node Course Carsales

Este projeto foi desenvolvido com Node.js, é a API para o curso de frontend com Angular.

## Ambiente de desenvolvimento

Para rodar o projeto é necessário ter o Nodejs 7.x ou maior instalado.
Instale o mongodb localmente ou crie um banco de dados remoto.
No arquivo config.js configure a conexão com o banco de dados.
Rode o comando `npm install` para instalar as dependências do projeto.
Rode o comando `npm start` para subir o servidor.
